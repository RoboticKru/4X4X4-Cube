/* FILE:    HC4x4x4.cpp
   DATE:    19/11/21
   VERSION: 1.0
   AUTHOR:  Andrew Davies
   
19/11/21 version 1.0: Original version

This library has been written for the Hobby components 4x4x4 LED cube kits
See hobbycomponents.com/4x4x4 for more information on these kits.

This library is provided free to support the open source community. PLEASE
SUPPORT HOBBY COMPONENTS so that we can continue to provide free content like
this by purchasing items from our store - HOBBYCOMPONENTS.COM 

You may copy, alter and reuse this code in any way you like, but please leave
reference to HobbyComponents.com in your comments if you redistribute this code.
This software may not be used directly for the purpose of selling products that
directly compete with Hobby Components Ltd's own range of products.
THIS SOFTWARE IS PROVIDED "AS IS". HOBBY COMPONENTS MAKES NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, ACCURACY 
OR LACK OF NEGLIGENCE.
HOBBY COMPONENTS SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR ANY DAMAGES,
INCLUDING, BUT NOT LIMITED TO, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER.
*/

#include "Arduino.h"
#include "HC4x4x4.h"

volatile uint16_t buffer[4];
uint8_t layerIndex = 0, _drawDir;


// Constructor to initiliase the library
HC4x4x4::HC4x4x4(void)
{
    // Nothing to do !    
}

// Initialise the ports and clear the buffer
void HC4x4x4::init(void)
{
    // Set all LED pins to outputs
    LED_0_7_PORT = ~LED_0_7_MASK;
    LED_0_7_DDR = LED_0_7_MASK;
  
    LED_8_13_PORT = ~LED_8_13_MASK;
    LED_8_13_DDR = LED_8_13_MASK;
  
    LED_14_15_PORT = 0x00;
    LED_14_15_DDR = 0xFF;


    #ifdef BASE_LEDS
    pinMode(BASE_LEDS, OUTPUT);
    baseLEDs(ON);
    #endif

    // Clear the LED buffer
    clear();

    // Set X, Y, Z reference point to front bottom left hand corner 
    _drawDir = FRONT_0;

    // Initialise hardware Timer2 with a 2.04mS interval. 
    // Note, version 1 cube uses Arduino bootloader running at 16MHz 
    // and version 2 cube uses miniCore bootloader running at 4MHz
    #ifdef SYSTEM_CLOCK_16MHZ
    CubeTimer2Init(T2_CLK_DIV_128, 254);
    #endif
    #ifdef SYSTEM_CLOCK_4MHZ
    CubeTimer2Init(T2_CLK_DIV_128, 64);
    #endif
}


// Internal function that converts an X, Y, Z coordinate into a bit location 
// within the LED buffer and taking into account the reference point where:
//
// x, y, & z are the LED coordinate
// *i is a pointer to an unsigned byte vairable that will contain the buffer index
// *b is a pointer to an unsigned byte vairable that will contain the bit position
//
// Returns: void
void HC4x4x4::_bitLoc(int16_t x, int16_t y, int16_t z, uint8_t *i, uint8_t *b)
{
    // Check if the coordinate is within the cube
    if(x >= 0 && x < 4 && y >= 0 && y < 4 && z >= 0 && z < 4)
    {
        // Bit location will depend on the xyz reference point
        switch(_drawDir)
        {
            case TOP_0:
                #ifdef VERSION_1
                *i = 3 - z;
                *b = ((x * 4) + (3 - y));
                #endif 

                #ifdef VERSION_2
                *i = z;
                *b = ((12 + y) - (x * 4));
                #endif 
                break;

            case TOP_90:
                #ifdef VERSION_1
                *i = 3 - z;
                *b = (x + (4 * y));
                #endif 

                #ifdef VERSION_2
                *i = z; *b = ((15 - 4 * y) - x);
                #endif 
                break;

            case TOP_180:
                #ifdef VERSION_1
                *i = 3 - z;
                *b = ((12 + y) - (x * 4));
                #endif 

                #ifdef VERSION_2
                *i = z;
                *b = ((x * 4) + (3 - y));
                #endif 
                break;

            case TOP_270:
                #ifdef VERSION_1
                *i = 3 - z;
                *b = ((15 - 4 * y) - x);
                #endif 

                #ifdef VERSION_2
                *i = z; *b = (x + (4 * y));
                #endif 
                break;


            case BOTTOM_0:
                #ifdef VERSION_1
                *i = z;
                *b = ((15 - y) - (4 * x));
                #endif 

                #ifdef VERSION_2
                *i = 3 - z; *b = ((x * 4) + y);
                #endif 
                break;

            case BOTTOM_90:
                #ifdef VERSION_1
                *i = z;
                *b = ((3 - x) + (4 * y));
                #endif 

                #ifdef VERSION_2
                *i = 3 - z; *b = x + ((12 - (y * 4)));
                #endif
                break;

            case BOTTOM_180:
                #ifdef VERSION_1
                *i = z;
                *b = ((x * 4) + y);
                #endif 

                #ifdef VERSION_2
                *i = 3 - z; *b = ((15 - y) - (4 * x));
                #endif 
                break;

            case BOTTOM_270:
                #ifdef VERSION_1
                *i = z;
                *b = x + ((12 - (y * 4)));
                #endif 

                #ifdef VERSION_2
                *i = 3 - z; *b = ((3 - x) + (4 * y));
                #endif 
                break;

            
            case FRONT_0:
                #ifdef VERSION_1
                *i = y;  *b = ((x * 4) + (3 - z)); 
                #endif

                #ifdef VERSION_2
                *i = 3 - y; *b = (((3 - x) * 4) + z);
                #endif
                break;


            case FRONT_90:
                #ifdef VERSION_1
                *i = 3 - x;  *b = ((y * 4) + (3 -z));
                #endif

                #ifdef VERSION_2
                *i = x; *b = ((3 - y) * 4) + z;
                #endif

                break;

            case FRONT_180:
                #ifdef VERSION_1
                *i = 3 - y;  *b = ((15 - (4 * x) ) - z);
                #endif

                #ifdef VERSION_2
                *i = y; *b = ((12 - (4 * (3 - x))) + z);
                #endif
                break;

            case FRONT_270:
                #ifdef VERSION_1
                *i = x;  *b = ((15 - (4 * y)) - z);
                #endif

                #ifdef VERSION_2
                *i = 3 - x; *b = ((12 - (4 * (3 - y))) + z);
                #endif
                break;


            case LEFT_0:
                #ifdef VERSION_1
                *i = y;
                *b = (x + (4 * z));
                #endif

                #ifdef VERSION_2
                *i = 3 - y; *b = ((3 - x) + (12 - (4 * z)));
                #endif
                break;

            case LEFT_90:
                #ifdef VERSION_1
                *i = 3 - x;
                *b = (y + (z * 4));
                #endif

                #ifdef VERSION_2
                *i = x; *b = ((3 - y) + (12 - (4 * z)));
                #endif
                break;


            case LEFT_180:
                #ifdef VERSION_1
                *i = 3 - y;
                *b = (3 - x) + (4 * z);
                #endif

                #ifdef VERSION_2
                *i = y; *b = ((15 - (z * 4)) - (3-x));
                #endif
                break;

            case LEFT_270:
                #ifdef VERSION_1
                *i = x;
                *b = (3 - y) + (4 * z);
                #endif

                #ifdef VERSION_2
                *i = 3 - x; *b = ((15 - (4 * z)) - (3 - y));
                #endif
                break;


            case BACK_0:
                #ifdef VERSION_1
                *i = y;
                *b = ((12 - (4 * x)) + z);
                #endif

                #ifdef VERSION_2
                *i = 3 - y;  *b = ((15 - (4 * (3 - x))) - z);
                #endif
                break;

            case BACK_90:
                #ifdef VERSION_1
                *i = 3 - x;
                *b = ((12 - (4 * y)) + z);
                #endif

                #ifdef VERSION_2
                *i = x;  *b = ((15 - (4 * (3 - y))) - z);
                #endif
                break;

            case BACK_180:
                #ifdef VERSION_1
                *i = 3 - y;
                *b = ((x * 4) + z);
                #endif

                #ifdef VERSION_2
                *i = y;  *b = (((3 - x) * 4) + (3 - z)); 
                #endif
                break;

            case BACK_270:
                #ifdef VERSION_1
                *i = x;
                *b = (y * 4) + z;
                #endif

                #ifdef VERSION_2
                *i = 3 - x;  *b = (((3 - y) * 4) + (3 -z));
                #endif
                break;


            case RIGHT_0:
                #ifdef VERSION_1
                *i = y;
                *b = ((15 - (z * 4)) - x);
                #endif

                #ifdef VERSION_2
                *i = 3 - y;  *b = ( x) + (4 * z);
                #endif
                break;

            case RIGHT_90:
                #ifdef VERSION_1
                *i = 3 - x;
                *b = ((15 - (4 * z)) - y);
                #endif

                #ifdef VERSION_2
                *i = x;  *b = (y) + (4 * z);   
                #endif
                break;

            case RIGHT_180:
                #ifdef VERSION_1
                *i = 3 - y;
                *b = (x + (12 - (4 * z)));
                #endif

                #ifdef VERSION_2
                *i = y;  *b = ((3-x) + (4 * z));
                #endif
                break;

            case RIGHT_270:
                #ifdef VERSION_1
                *i = x;
                *b = (y + (12 - (4 * z)));
                #endif

                #ifdef VERSION_2
                *i = 3 - x;  *b = ((3-y) + (z * 4));
                #endif
                break;   
        }
    }
}



// Sets the state of one of the cubes LEDS where:
//
// x, y, & z are signed integer values containing the coordinates of the LED. 
// Valid values are 0 to 3. Note values outside this range are ignored.
//
// mode specifies the state to set the LED to. Valide values for mode are:
// ON       Turns the LED on
// OFF      Turns the LED off
// INVERT   Inverts the current state of the LED
//
// Note if the mode parameter is omitted the LED will be tuned on
//
// Returns: void
void HC4x4x4::plot(int16_t x, int16_t y, int16_t z, uint8_t mode)
{
    uint8_t i, b;

    // Check if the coordinate is within the cube
    if(x >= 0 && x < 4 && y >= 0 && y < 4 && z >= 0 && z < 4)
    {
        // Get its bit location within the LED buffer
        _bitLoc(x, y, z, &i, &b);

        switch(mode)
        {
            // Turn the LED on
            case ON:
                buffer[i] |= (1 << b);
                break;

            // Turn the LED off
            case OFF:
                buffer[i] &= ~(1 << b);
                break;

            // Invert the LEDs state
            case INVERT:
                buffer[i] ^= (1 << b);
                break;
        }
    }
}



// Gets the current state of the LED where:
//
// x, y, & z are signed integer values containing the coordinates of the LED. 
//
// Returns: A boolean value representing the current state of the LED
boolean HC4x4x4::get(int16_t x, int16_t y, int16_t z)
{
    // Check if the coordinate is within the cube
    if(x >= 0 && x < 4 && y >= 0 && y < 4 && z >= 0 && z < 4)
    {
        uint8_t i, b;

        // Get its bit location within the LED buffer
        _bitLoc(x, y, z, &i, &b);

        // Return its current state
        return buffer[i] & (1 << b);
    }else // coordinate is not inside the cube so just return 0 (off)
    return 0;
}



// Shifts the entire grid of LEDs in one direction where:
//
// dir is the direction to shift. Valide values for dir are:
//  LEFT        Shifts all the LEDs +1 position in the x axis
//  RIGHT       Shifts all the LEDs -1 position in the x axis
//  UP          Shifts all the LEDs +1 position in the y axis
//  DOWN        Shifts all the LEDs -1 position in the y axis
//  FORWARD     Shifts all the LEDs +1 position in the z axis
//  BACKWARD    Shifts all the LEDs -1 position in the z axis
//
// Returns: void
void HC4x4x4::shift(uint8_t dir)
{
    // Step through each x,y, & z coordinate and shift it depending on dir
    for(uint8_t z = 0; z < 4; z++)
        for(uint8_t y = 0; y < 4; y++)
            for(uint8_t x = 0; x < 4; x++)
                switch(dir)
                {
                    // Shift +1 in x axis
                    case LEFT:
                        if(x > 0)
                        {
                            plot(x - 1, y, z, get(x,y,z));
                            if(x == 3);
                                plot(x, y, z, OFF);
                        }
                        break;

                    // Shift -1 in x axis
                    case RIGHT:
                        if(x > 0)
                        {
                            uint8_t rx = 3 - x;
                            plot(rx + 1, y, z, get(rx, y, z));
                            if(x == 3);
                                plot(rx, y, z, OFF);
                        }         
                        break;

                    // Shift +1 in y axis
                    case UP:
                        if(y > 0)
                        {
                            uint8_t ry = 3 - y;
                            plot(x, ry + 1, z, get(x, ry, z));
                            if(y == 3);
                                plot(x, ry, z, OFF);
                        }         
                        break;

                    // Shift -1 in y axis
                    case DOWN:
                        if(y > 0)
                        {
                            plot(x, y - 1, z, get(x,y,z));
                            if(y == 3);
                                plot(x, y, z, OFF);
                        }
                        break;

                    // Shift +1 in z axis
                    case BACKWARD:
                        if(z > 0)
                        {
                            uint8_t rz = 3 - z;
                            plot(x, y, rz + 1, get(x, y, rz));
                            if(y == 3);
                                plot(x, y, rz, OFF);
                        }         
                        break;  

                    // Shift -1 in z axis
                    case FORWARD:
                        if(z > 0)
                        {
                            plot(x, y, z - 1, get(x,y,z));
                            if(z == 3);
                                plot(x, y, z, OFF);
                        }
                        break;
                }
}



// Draws a line of 1 LED thickness in 3d where:
//
// x1, y1, z1 is the x,y,z coordinate of the start of the line 
// x2, y2, z2 is the x,y,z coordinate of the end of the line
//
// mode specifies the state to set the LED to. Valide values for mode are:
// ON       Turns the LED on
// OFF      Turns the LED off
// INVERT   Inverts the current state of the LED
//
// Returns: void 
void HC4x4x4::line(uint8_t x1, uint8_t y1, uint8_t z1, uint8_t x2, uint8_t y2, uint8_t z2, uint8_t mode)
{
	double stepX, stepY, stepZ;
	uint8_t index;

	// If the line is longer in the x axis then calculate the y & z step
    // size based on the x axis
	if(_Diff(x1, x2) >= _Diff(y1,y2) && _Diff(x1, x2) >= _Diff(z1, z2))
	{
		stepX = 1;
		if(x1 > x2)
			stepX = -1;

		_Diff(y2,y1)? stepY = (double)(y2 - y1)/_Diff(x2,x1) : 1;
		_Diff(z2,z1)? stepZ = (double)(z2 - z1)/_Diff(x2,x1) : 1;
		
		for(index =0; index <= _Diff(x2,x1); index++)
		{
			plot((stepX*index) +x1, (stepY*index)+y1, (stepZ*index)+z1, mode);	
		}

    // If the line is longer in the y axis then calculate the x & z step
    // size based on the y axis
	}else if(_Diff(y1, y2) > _Diff(x1,x2) && _Diff(y1,y2) > _Diff(z1, z2))
	{
		stepY = 1;
		if(y1 > y2)
			stepY = -1;
		
		_Diff(x2,x1)? stepX = (double)(x2 - x1)/_Diff(y2,y1) : 1;
		_Diff(z2,z1)? stepZ = (double)(z2 - z1)/_Diff(y2,y1) : 1;
		
		for(index =0; index <= _Diff(y2,y1); index++)
		{
			plot((stepX*index)+x1, (stepY*index)+y1, (stepZ*index)+z1, mode);	
		}
    // If the line is longer in the z axis then calculate the x & y step
    // size based on the z axis		
	}else
	{
		stepZ = 1;
		if(z1 > z2)
			stepZ = -1;
		
		_Diff(x2,x1)? stepX = (double)(x2 - x1)/_Diff(z2,z1) : 1;
		_Diff(y2,y1)? stepY = (double)(y2 - y1)/_Diff(z2,z1) : 1;
		
		for(index =0; index <= _Diff(z2,z1); index++)
		{
			plot((stepX*index)+x1, (stepY*index)+y1, (stepZ*index)+z1, mode);	
		}		
	}	
}



// Prints an alphanumeric character where:
//
// c is a char vairable containing the character to print
//
// col is the column position on the cube from where to start displaying the character from
//
// layer is the z axis layer to print the character on
void HC4x4x4::printChar(char c, int16_t col, uint8_t layer)
{
    // Character must be between ASCII range ' ' & '+'
    if(c >= ' ' && c <= '~')
    {
        // Calculate index for the character in the font bitmap array
        // Note each character takes up 4 bytes in the array
        uint16_t i = (c - ' ') * 4;

        // Get the width of the character
        uint8_t colMax = 4 - pgm_read_byte_near(&pixel4x4_4ptDescriptors[c - ' ']);

        // Plot the character to the cube
        for(uint8_t y = 0; y < 4; y++)
            for(uint8_t x = colMax; x < 4; x++)
            {
                boolean state = pgm_read_byte_near(&tiny_4pt[i + 3 - y]) & (1 << (3 - x));
                plot(x - colMax + col, y, layer, state);
            }
    }
}



// Prints a string of text to the cube where:
//
// *text is a pointer to the start of a null terminated character array containing the text
//
// col is the column position on the cube from where to start displaying the text from
//
// layer is the z axis layer to print the text on
void HC4x4x4::print(char* text, int16_t col, uint8_t layer)
{
    uint8_t i = 0;

    // Keep printing text until we reach the null terminator
    while(text[i] != '\0')
    {
        char c = text[i];
        printChar(c, col, layer);
        col += pgm_read_byte_near(&pixel4x4_4ptDescriptors[c - ' ']) + 1;
        i++;
    }
}



// Automatically scrolls a string of text across the cube where:
//
// *text is a pointer to the start of a null terminated character array containing the text
//
// length is a integer value containing length of the string in bytes
//
// Returns: void 
void HC4x4x4::printScroll(char* text, /*int16_t len, */ uint16_t delayms, uint8_t layer)
{
    uint8_t i = 0;;
    int16_t len = 0;

    // Calculate how many pixels wide the text string is
    while(text[i] != '\0')
    {
        len -= pgm_read_byte_near(&pixel4x4_4ptDescriptors[text[i] - ' ']) + 1;
        i++;
    }

    // Scroll the text
    for(int16_t i = 3; i > len; i--)
    {
        clear();
        print(text, i, layer);
        delay(delayms);
    }
}



// Used to display a 3D cube primitive where:
// x1 is the x axis coordinate for the first corner of the cube.
// y1 is the y axis coordinate for the first corner of the cube.
// z1 is the z axis coordinate for the first corner of the cube.
// x2 is the x axis coordinate for the opposite corner of the cube.
// y2 is the y axis coordinate for the opposite corner of the cube.
// z2 is the z axis coordinate for the opposite corner of the cube.
// valid values for x1, y1, z1, x2, y2, z2 are from 0 to 7
// 
// solid specifies whether the cube should be drawn solid (filled in) or wire frame */
//
// mode specifies the state to set the LED to. Valide values for mode are:
// ON       Turns the LED on
// OFF      Turns the LED off
// INVERT   Inverts the current state of the LED
//
// Returns: void
void HC4x4x4::cube(int16_t x1, int16_t y1, int16_t z1, int16_t x2, int16_t y2, int16_t z2, boolean solid, uint8_t mode)
{
	int16_t XIndex, YIndex, ZIndex;
	
	/* Check that specified coordinates are not outside the LED cube */
/*	if(x1 > 3)
		x1 = 3;
	if(x2 > 3)
		x2 = 3;
	if(y1 > 3)
		y1 = 3;
	if(y2 > 3)
		y2 = 3;
	if(z1 > 3)
		z1 = 3;
	if(z2 > 3)
		z2 = 3;*/
	
	
	/* The opposite coordinate needs to be the greater of the to so if it 
	   isn't then flip the coordinates */
	if(x2 < x1)
	{
		x1 = x1 xor x2;
		x2 = x1 xor x2;
		x1 = x1 xor x2;
	}
	if(y2 < y1)
	{
		y1 = y1 xor y2;
		y2 = y1 xor y2;
		y1 = y1 xor y2;
	}
	if(z2 < z1)
	{
		z1 = z1 xor z2;
		z2 = y1 xor z2;
		z1 = y1 xor z2;
	}
	
	/* Draw the cube */
	for(XIndex = x1; XIndex <= x2; XIndex++)
	{
		for(YIndex = y1; YIndex <= y2; YIndex++)
		{
			for(ZIndex = z1; ZIndex <= z2; ZIndex++)
			{	
				if(((XIndex == x1 || XIndex == x2) && (YIndex == y1 || YIndex == y2) ||
					(ZIndex == z1 || ZIndex == z2) && (YIndex == y1 || YIndex == y2) ||
					(ZIndex == z1 || ZIndex == z2) && (XIndex == x1 || XIndex == x2)) || solid)
                    plot(XIndex, YIndex, ZIndex, mode);
			}
		}
	}
}




// Draws a circle where:
//
// x, y, & z are floats containing the coordinates of the centre of the circle
//
// r is a float value containing the radius of the circle 
//
// Returns: void
void HC4x4x4::circle(float x, float y, uint8_t z, uint8_t r)  
{
    for(int16_t x = 0; x < 4; x++)
        for(int16_t y = 0; y < 4; y++)
            if(round(_pol(x - x, y - y)) == r)
                plot(x,y,z);
}


float HC4x4x4::_pol(float x, float y)  
{
    return sqrt((x*x) + (y*y));
}



/*void HC4x4x4::printWrap(char text[], int16_t col)
{
    uint8_t tmp = _drawDir;

    _drawDir = LEFT_0;
    print(text, col, 0);

    _drawDir = FRONT_0;
    print(text, col - 3, 0);

    _drawDir = RIGHT_0;
    print(text, col - 6, 0);

    _drawDir = tmp;
}*/




/* An internal library function which returns the difference between to numbers */
uint8_t HC4x4x4::_Diff(uint8_t a, uint8_t b)
{
	uint8_t result;
	if(a > b)
	{
		result = a - b;
	}else
	{
		result = b - a;
	}
	
	if(result == 0)
		result = 1;
	return result;
}



// Clears (turns off) all cube LEDs
//
// Returns: void
void HC4x4x4::clear(void)
{
    buffer[0] = 0;
    buffer[1] = 0;
    buffer[2] = 0;
    buffer[3] = 0;
}



// Sets the drawing orientation where:
// dir is the required direction. Valid values for dir are
//  TOP_0           
//  TOP_90          
//  TOP_180         
//  TOP_270         
//  BOTTOM_0        
//  BOTTOM_90       
//  BOTTOM_180      
//  BOTTOM_270      
//  FRONT_0         
//  FRONT_90        
//  FRONT_180       
//  FRONT_270       
//  LEFT_0          
//  LEFT_90         
//  LEFT_180        
//  LEFT_270        
//  BACK_0          
//  BACK_90         
//  BACK_180        
//  BACK_270        
//  RIGHT_0         
//  RIGHT_90        
//  RIGHT_180       
//  RIGHT_270       
//
// Returns: void
void HC4x4x4::setDrawDir(uint8_t dir)
{
    _drawDir = dir;
}



// Turns on or off the base LEDs where:
//
// state is the required state of the LEDs. Valid values for state are
//  OFF
//  ON
//
// Returns: void
#ifdef BASE_LEDS
void HC4x4x4::baseLEDs(boolean state)
{
    if(state)
        digitalWrite(BASE_LEDS, HIGH);
    else
        digitalWrite(BASE_LEDS, LOW);
}
#endif


// Timer interrupt that sets the state of the cube LEDs based on 
// the state of the LED buffer.
void HC4x4x4::_CubeTimer2()
{
    ROW_PORT = (ROW_PORT & ~ROW_MASK);

    LED_0_7_PORT = buffer[layerIndex];
    LED_8_13_PORT =  (LED_8_13_PORT & ~LED_8_13_MASK) | ((buffer[layerIndex] >> 8) & LED_8_13_MASK);
    LED_14_15_PORT = (LED_14_15_PORT & ~LED_14_15_MASK) | ((buffer[layerIndex] >> 14) & LED_14_15_MASK);

    ROW_PORT = (ROW_PORT & ~ROW_MASK) | (0b100 << layerIndex);


    if(layerIndex < 3)
        layerIndex++;
    else
        layerIndex = 0;
}



/* Reconfigures the hardware timer 2. Used to automatically refresh the matrix */
void HC4x4x4::CubeTimer2Init(byte prescaler, byte compare)
{
	/* Turn off interrupts whilst we setup the timer */
	cli();
	/* Set timer mode to clear timer on compare match (mode 2)*/
	TCCR2A = (1<<WGM21);

	/* Set the prescaler */
	TCCR2B = prescaler;

	/* Clear timer 2 counter */
	TCNT2 = 0;

	/* Set the compare match register */
	OCR2A = compare;

	/* Enable timer 2 interrupt on compare match */
	TIMSK2 = (1<<OCIE2A);

  	/* Turn interrupts back on */
  	sei();
}



/* Interrupt service routine for Timer 2 compare match */
ISR(TIMER2_COMPA_vect)
{
   HC4x4x4::_CubeTimer2();
}