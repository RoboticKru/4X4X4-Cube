/* FILE:    HC4x4x4.h
   DATE:    19/11/21
   VERSION: 1.0
   AUTHOR:  Andrew Davies
   
19/11/21 version 1.0: Original version

This library has been written for the Hobby components 4x4x4 LED cube kits
See hobbycomponents.com/4x4x4 for more information on these kits.

This library is provided free to support the open source community. PLEASE
SUPPORT HOBBY COMPONENTS so that we can continue to provide free content like
this by purchasing items from our store - HOBBYCOMPONENTS.COM 

You may copy, alter and reuse this code in any way you like, but please leave
reference to HobbyComponents.com in your comments if you redistribute this code.
This software may not be used directly for the purpose of selling products that
directly compete with Hobby Components Ltd's own range of products.
THIS SOFTWARE IS PROVIDED "AS IS". HOBBY COMPONENTS MAKES NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, ACCURACY 
OR LACK OF NEGLIGENCE.
HOBBY COMPONENTS SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR ANY DAMAGES,
INCLUDING, BUT NOT LIMITED TO, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER.
*/

#ifndef HC4x4x4_h
#define HC4x4x4_h

#include <avr/interrupt.h>
#include "version.h"

#if !defined (CUBE_VERSION_1) &&  !defined (CUBE_VERSION_1_NO_XTAL) && !defined (CUBE_VERSION_2)
#error Cube version not defined! Please see version.h file
#endif

/****************************************************************************/
//							CUBE HARDWARE SETTINGS
/****************************************************************************/
#ifdef CUBE_VERSION_1
#define VERSION_1
#define SYSTEM_CLOCK_16MHZ
#endif 

#ifdef CUBE_VERSION_1_NO_XTAL
#define VERSION_1
#define SYSTEM_CLOCK_4MHZ
#endif

#ifdef CUBE_VERSION_2
#define VERSION_2
#define SYSTEM_CLOCK_4MHZ
#define BASE_LEDS
#endif
/****************************************************************************/


/****************************************************************************/
//								  PINOUTS
/****************************************************************************/
#define LED_0_7_PORT PORTD
#define LED_0_7_DDR DDRD
#define LED_0_7_MASK 0xFF

#define LED_8_13_PORT PORTB
#define LED_8_13_DDR DDRB
#define LED_8_13_MASK 0x3F

#define LED_14_15_PORT PORTC
#define LED_14_15_DDR DDRC
#define LED_14_15_MASK 0x03

#define ROW_PORT PORTC
#define ROW_DDR DDRC
#define ROW_MASK 0x3C

#define BASE_LEDS PIN_PB7
/****************************************************************************/


/****************************************************************************/
//						 LIBRARY COMMAND PARAMETERS
/****************************************************************************/
enum dirIndex
{
    TOP_0           = 0,
    TOP_90          = 1,
    TOP_180         = 2,
    TOP_270         = 3,
    BOTTOM_0        = 4,
    BOTTOM_90       = 5,
    BOTTOM_180      = 6,
    BOTTOM_270      = 7,
    FRONT_0         = 8,
    FRONT_90        = 9,
    FRONT_180       = 10,
    FRONT_270       = 11,
    LEFT_0          = 12,
    LEFT_90         = 13,
    LEFT_180        = 14,
    LEFT_270        = 15,
    BACK_0          = 16,
    BACK_90         = 17,
    BACK_180        = 18,
    BACK_270        = 19,
    RIGHT_0         = 20,
    RIGHT_90        = 21,
    RIGHT_180       = 22,
    RIGHT_270       = 23
};



enum drawMode
{
    OFF             = 0,
    ON             	= 1,
    INVERT          = 2,
};

enum shiftDir
{
    LEFT            = 0,
    RIGHT           = 1,
    UP              = 2,
    DOWN            = 3,
    FORWARD         = 4,
	BACKWARD        = 5
};
/****************************************************************************/


/****************************************************************************/
//						 TIMER INTERRUPT PARAMETERS
/****************************************************************************/
/* Timer 2 clock prescalling values */
enum CubeT2PreScaller
{
	T2_CLK_DIV_0    = 1,
	T2_CLK_DIV_8    = 2,
	T2_CLK_DIV_32   = 3,
	T2_CLK_DIV_64   = 4,
    T2_CLK_DIV_128  = 5,
    T2_CLK_DIV_256  = 6,
    T2_CLK_DIV_1024 = 7
};

void CubeTimer2Init(byte prescaler, byte compare);
/****************************************************************************/


/****************************************************************************/
//						 FONT DATA FOR TINY 4PT FONT
/****************************************************************************/

// Character bitmaps for Tiny 4pt
const PROGMEM uint8_t tiny_4pt[] = 
{
	// @0 ' ' (4 pixels wide)
	0b0000, //  
	0b0000, //  
	0b0000, //  
	0b0000, //  

	// @0 '!' (1 pixels wide)
	0b0001, // #
	0b0001, // #
	0b0000, // #
	0b0001, //  

	// @4 '"' (3 pixels wide)
	0b0101, // # #
	0b0101, // # #   
	0b0000, //    
	0b0000, //    

	// @8 '#' (4 pixels wide)
	0b0110, //  ##
	0b1111, // #### 
	0b1111, // ####
	0b0110, //  ## 

	// @12 '$' (4 pixels wide)
	0b0111, //  ###
	0b1010, // # #
	0b1111, // ####
	0b1110, // ###

	// @16 '%' (4 pixels wide)
	0b1001, // #  #
	0b0010, //   # 
	0b0100, //  # 
	0b1001, // #  #  

	// @20 '&' (4 pixels wide)
	0b0110, //  ##
	0b1000, // #
	0b1101, // ## #
	0b1010, // # #

	// @24 ''' (1 pixels wide)
	0b0001, // #
	0b0001, // #  
	0b0000, //  
	0b0000, //  

	// @28 '(' (2 pixels wide)
	0b0001, //  #
	0b0010, // # 
	0b0010, // # 
	0b0001, //  #

	// @32 ')' (2 pixels wide)
	0b0010, // #
	0b0001, //  #
	0b0001, //  #
	0b0010, // # 

	// @36 '*' (4 pixels wide)
	0b1001, // #  #
	0b0110, //  ##
	0b0110, //  ##
	0b1001, // #  #

	// @40 '+' (3 pixels wide)
	0b0010, //   # 
	0b0111, //  ###
	0b0010, //   # 
	0b0000, //    

	// @44 ',' (2 pixels wide)
	0b0000, //  
	0b0000, //  
	0b0001, //    #
	0b0010, //   #

	// @48 '-' (4 pixels wide)
	0b0000, //    
	0b0000, //
	0b1111, // ####    
	0b0000, //    

	// @52 '.' (1 pixels wide)
	0b0000, //  
	0b0000, //  
	0b0000, // 
	0b0001, // # 

	// @56 '//' (4 pixels wide)
	0b0001, //    #
	0b0010, //   # 
	0b0100, //  #  
	0b1000, // #   

	// @60 '0' (4 pixels wide)
	0b1111, // ####
	0b1001, // #  #
	0b1001, // #  # 
	0b1111, // ####   

	// @64 '4' (1 pixels wide)
	0b0010, //    # 
	0b0110, //  # # 
	0b0010, //    #
	0b1111, //  ####   

	// @68 '2' (4 pixels wide)
	0b1111, // ####
	0b0010, //   #  
	0b0100, //  #
	0b1111, // ####   

	// @72 '3' (4 pixels wide)
	0b1111, // ####
	0b0111, //  ###
	0b0001, //    #
	0b1111, // ####   

	// @76 '4' (4 pixels wide)
	0b0011, //   ##
	0b0101, //  # #
	0b1111, // ####
	0b0001, //    # 

	// @80 '5' (4 pixels wide)
	0b1111, // ####
	0b1000, // #
	0b1111, // #### 
	0b0111, //  ###

	// @84 '6' (4 pixels wide)
	0b1000, // #
	0b1111, // ####
	0b1001, // #  #
	0b1111, // ####   

	// @88 '7' (4 pixels wide)
	0b1111, // ####
	0b0001, //    # 
	0b0001, //    #  
	0b0001, //    #

	// @92 '8' (4 pixels wide)
	0b1110, // ###
	0b1011, // # ##
	0b1101, // ## #
	0b0111, //  ###  

	// @96 '9' (4 pixels wide)
	0b1111, // ####
	0b1001, // #  #
	0b1111, // ####
	0b0001, //    #

	// @100 ':' (1 pixels wide)
	0b0001, //    #
	0b0000, //  
	0b0001, //    #
	0b0000, //  

	// @104 ';' (2 pixels wide)
	0b0001, //    #
	0b0000, //  
	0b0001, //    #
	0b0010, //   #

	// @108 '<' (2 pixels wide)
	0b0001, //    #
	0b0010, //   #  
	0b0001, //    # 
	0b0000, //   

	// @112 '=' (3 pixels wide)
	0b0111, //  ###
	0b0000, //    
	0b0111, //  ###
	0b0000, //    

	// @116 '>' (2 pixels wide)
	0b0010, //    # 
	0b0001, //     #
	0b0010, //    # 
	0b0001, //   

	// @120 '?' (4 pixels wide)
	0b1111, // ####
	0b0011, //   ##  
	0b0000, //   
	0b0010, //   #  

	// @124 '@' (4 pixels wide)
	0b1100, // ##
	0b1010, // # # 
	0b1011, // # ##
	0b1100, // ##  

	// @128 'A' (4 pixels wide)
	0b1111, // ####
	0b1001, // #  #
	0b1111, // ####
	0b1001, // #  #

	// @132 'B' (4 pixels wide)
	0b1100, // ##
	0b1010, // # #
	0b1101, // ## # 
	0b1010, // # #

	// @136 'C' (4 pixels wide)
	0b0111, //  ###
	0b1000, // #  
	0b1000, // #
	0b0111, //  ###  

	// @140 'D' (4 pixels wide)
	0b1110, // ###
	0b1001, // #  #
	0b1001, // #  # 
	0b1110, // ###   

	// @144 'E' (4 pixels wide)
	0b1111, // ####
	0b1110, // ###  
	0b1000, // #
	0b1111, // ####   

	// @148 'F' (4 pixels wide)
	0b1111, // ####
	0b1000, // # 
	0b1110, // ###  
	0b1000, // #   

	// @152 'G' (4 pixels wide)
	0b0111, //  ###
	0b1000, // # 
	0b1001, // #  #
	0b0111, //  ###   

	// @156 'H' (4 pixels wide)
	0b1001, // #  #
	0b1001, // #  #
	0b1111, // ####
	0b1001, // #  #   

	// @160 'I' (4 pixels wide)
	0b1111, // ####
	0b0100, //  # 
	0b0100, //  #
	0b1111, // ####  

	// @164 'J' (4 pixels wide)
	0b1111, // ####
	0b0001, //    #
	0b1001, // #  # 
	0b1110, // ### 

	// @168 'K' (4 pixels wide)
	0b1011, // # ###
	0b1100, // ##
	0b1010, // # #
	0b1001, // #  #   

	// @172 'L' (4 pixels wide)
	0b1000, // #  
	0b1000, // #  
	0b1000, // #
	0b1111, // ####  

	// @176 'M' (4 pixels wide)
	0b1111, // ####
	0b1011, // # ##
	0b1001, // #  #
	0b1001, // #  #

	// @180 'N' (4 pixels wide)
	0b1101, // ## #
	0b1011, // # ##
	0b1001, // #  #
	0b1001, // #  #   

	// @184 'O' (4 pixels wide)
	0b0110, //  ## 
	0b1001, // #  #
	0b1001, // #  #
	0b0110, //  ## 

	// @188 'P' (4 pixels wide)
	0b1110, // ### 
	0b1001, // #  # 
	0b1110, // ###   
	0b1000, // #   

	// @192 'Q' (4 pixels wide)
	0b0110, //  ## 
	0b1001, // #  #
	0b1011, // # ##
	0b0111, //  ###

	// @196 'R' (4 pixels wide)
	0b1110, // ### 
	0b1001, // #  # 
	0b1111, // ####
	0b1010, // # #

	// @200 'S' (4 pixels wide)
	0b1111, // ####
	0b1000, // #
	0b1111, // #### 
	0b0111, //  ###

	// @204 'T' (4 pixels wide)
	0b1111, // ####
	0b0100, //  # 
	0b0100, //  # 
	0b0100, //  #

	// @208 'U' (4 pixels wide)
	0b1001, // #  #
	0b1001, // #  #
	0b1001, // #  #
	0b1111, // ####  

	// @212 'V' (4 pixels wide)
	0b1001, // #  #
	0b1001, // #  # 
	0b1001, // #  #
	0b0110, //  ##

	// @216 'W' (4 pixels wide)
	0b1001, // #  #
	0b1001, // #  #
	0b1011, // # ## 
	0b1111, // ####

	// @220 'X' (4 pixels wide)
	0b1001, // #  #
	0b0110, //  ##
	0b0110, //  ##
	0b1001, // #  #

	// @224 'Y' (4 pixels wide)
	0b1001, // #  #
	0b1001, // #  # 
	0b1111, // ####
	0b0100, //  #

	// @228 'Z' (4 pixels wide)
	0b1111, // ####
	0b0010, //   # 
	0b0100, //  #
	0b1111, // ####

	// @232 '[' (2 pixels wide)
	0b0011, //   ##
	0b0010, //   # 
	0b0010, //   # 
	0b0011, //   ##

	// @236 '\\' (4 pixels wide)
	0b1000, // # 
	0b0100, //  #
	0b0010, //   #
	0b0001, //    #  

	// @240 ']' (2 pixels wide)
	0b0011, //   ##
	0b0001, //    #
	0b0001, //    # 
	0b0011, //   ##

	// @244 '^' (3 pixels wide)
	0b0010, //  #
	0b0101, // # #  
	0b0000, //    
	0b0000, //    

	// @248 '_' (4 pixels wide)
	0b0000, //    
	0b0000, //    
	0b0000, //    
	0b1111, // ####

	// @252 '`' (2 pixels wide)
	0b0010, //    #
	0b0001, //     # 
	0b0000, //   
	0b0000, //   

	// @256 'a' (3 pixels wide)
	0b0000, //  
	0b0011, //   ##
	0b0101, //  # #
	0b0011, //   ##

	// @260 'b' (3 pixels wide)
	0b0100, // # 
	0b0110, // ##
	0b0101, // # # 
	0b0110, // ##   

	// @264 'c' (3 pixels wide)
	0b0000, //  
	0b0011, //   ##  
	0b0100, //  #
	0b0011, //   ## 

	// @268 'd' (3 pixels wide)
	0b0001, //   #
	0b0011, //  ##
	0b0101, // # #
	0b0011, //  ## 

	// @272 'e' (3 pixels wide)
	0b0000, //  
	0b0011, //   ##
	0b0110, //  ##
	0b0011, //   ##

	// @276 'f' (3 pixels wide)
	0b0000, //  
	0b0111, //   ###
	0b1110, //  ### 
	0b1000, //  #

	// @280 'g' (3 pixels wide)
	0b0111, //  ###
	0b0111, //  ###
	0b0001, //    #
	0b0111, //  ###

	// @284 'h' (3 pixels wide)
	0b1000, //  # 
	0b1100, //  ##
	0b1010, //  # #
	0b1010, //  # # 

	// @288 'i' (1 pixels wide)
	0b0001, //    #
	0b0000, // 
	0b0001, //    #
	0b0001, //    #

	// @292 'j' (3 pixels wide)
	0b0001, //    #
	0b0000, //   
	0b0001, //    #
	0b0111, //  ###

	// @296 'k' (3 pixels wide)
	0b0100, //  # 
	0b0101, //  # # 
	0b0100, //  ##
	0b0101, //  # #

	// @300 'l' (1 pixels wide)
	0b0001, //    #
	0b0001, //    #
	0b0001, //    #
	0b0001, //    #

	// @304 'm' (4 pixels wide)
	0b0000, // 
	0b1111, // ####
	0b1011, // # ##
	0b1011, // # ##   

	// @308 'n' (3 pixels wide)
	0b0000, //  
	0b0110, //  ##
	0b0101, //  # #
	0b0101, //  # #  

	// @312 'o' (3 pixels wide)
	0b0000, // 
	0b0111, //  ###
	0b0101, //  # #
	0b0111, //  ### 

	// @316 'p' (3 pixels wide)
	0b0110, //  ## 
	0b0101, //  # #
	0b0110, //  ## 
	0b0100, //  #  

	// @320 'q' (3 pixels wide)
	0b0011, //   ##
	0b0101, //  # #
	0b0011, //   ##
	0b0001, //    #

	// @324 'r' (2 pixels wide)
	0b0000, // 
	0b0011, //   ## 
	0b0010, //   # 
	0b0010, //   # 

	// @328 's' (3 pixels wide)
	0b0011, //  
	0b0010, //    ## 
	0b0010, //    # 
	0b0110, //   ## 

	// @332 't' (3 pixels wide)
	0b0010, //   #
	0b0111, //  ### 
	0b0010, //   # 
	0b0011, //   ##

	// @336 'u' (3 pixels wide)
	0b0000, // 
	0b0101, //  # #
	0b0101, //  # #
	0b0011, //   ##  

	// @340 'v' (3 pixels wide)
	0b0000, // 
	0b0101, //  # #
	0b0101, //  # # 
	0b0010, //   #  

	// @344 'w' (4 pixels wide)
	0b0000, // 
	0b1001, //  #  #
	0b1011, //  # ## 
	0b0110, //   ## 

	// @348 'x' (3 pixels wide)
	0b0000, // 
	0b0101, //  # #
	0b0010, //   #
	0b0101, //  # #

	// @352 'y' (3 pixels wide)
	0b0101, //  # #
	0b0111, //  ###
	0b0001, //    #
	0b0110, //  ## 

	// @356 'z' (3 pixels wide)
	0b0000, // 
	0b0111, //  ### 
	0b0010, //   #
	0b0111, //  ### 

	// @360 '{' (3 pixels wide)
	0b0011, //   ##
	0b0110, //  ## 
	0b0010, //   # 
	0b0011, //   ##

	// @364 '|' (1 pixels wide)
	0b0001, //    #
	0b0001, //    #
	0b0001, //    #
	0b0001, //    #

	// @368 '}' (3 pixels wide)
	0b0110, //  ## 
	0b0011, //   ##
	0b0010, //   # 
	0b0110, //  ## 

	// @372 '~' (4 pixels wide)
	0b0101, //   # #
	0b1010, //  # #
	0b0000, //    
	0b0000, //    
};


/* Character descriptors for Pixel 4x4 4pt */
/* { [Char width in bits], [Offset into pixel4x4_4ptCharBitmaps in bytes] } */
const PROGMEM uint8_t pixel4x4_4ptDescriptors[] = 
{
	4,		/*   */
	1, 		/* ! */ 
	3, 		/* " */ 
	4, 		/* # */ 
	4, 		/* $ */ 
	4, 		/* % */ 
	4, 		/* & */ 
	1, 		/* ' */ 
	2, 		/* ( */ 
	2, 		/* ) */ 
	4, 		/* * */ 
	3, 		/* + */ 
	2, 		/* , */ 
	4, 		/* - */ 
	1, 		/* . */ 
	4, 		/* / */ 
	4, 		/* 0 */ 
	4, 		/* 1 */ 
	4, 		/* 2 */ 
	4, 		/* 3 */ 
	4, 		/* 4 */ 
	4, 		/* 5 */ 
	4, 		/* 6 */ 
	4, 		/* 7 */ 
	4, 		/* 8 */ 
	4, 		/* 9 */ 
	1, 		/* : */ 
	2, 		/* ; */ 
	2, 		/* < */ 
	3, 		/* = */ 
	2, 		/* > */ 
	4, 		/* ? */ 
	4, 		/* @ */ 
	4, 		/* A */ 
	4, 		/* B */ 
	4, 		/* C */ 
	4, 		/* D */ 
	4, 		/* E */ 
	4, 		/* F */ 
	4, 		/* G */ 
	4, 		/* H */ 
	4, 		/* I */ 
	4, 		/* J */ 
	4, 		/* K */ 
	4, 		/* L */ 
	4, 		/* M */ 
	4, 		/* N */ 
	4, 		/* O */ 
	4, 		/* P */ 
	4, 		/* Q */ 
	4, 		/* R */ 
	4, 		/* S */ 
	4, 		/* T */ 
	4, 		/* U */ 
	4, 		/* V */ 
	4, 		/* W */ 
	4, 		/* X */ 
	4, 		/* Y */ 
	4, 		/* Z */ 
	2, 		/* [ */ 
	4, 		/* \ */ 
	2, 		/* ] */ 
	3, 		/* ^ */ 
	4, 		/* _ */ 
    2, 		/* ` */ 
	3, 		/* a */ 
	3, 		/* b */ 
	3, 		/* c */ 
	3, 		/* d */ 
	3, 		/* e */ 
	3, 		/* f */ 
	3, 		/* g */ 
	3, 		/* h */ 
	1, 		/* i */ 
	3, 		/* j */ 
	1, 		/* k */ 
	1, 		/* l */ 
	4, 		/* m */ 
	3, 		/* n */ 
	3, 		/* o */ 
	3, 		/* p */ 
	3, 		/* q */ 
	2, 		/* r */ 
	3, 		/* s */ 
	3, 		/* t */ 
	3, 		/* u */ 
	3, 		/* v */ 
	4, 		/* w */ 
	3, 		/* x */ 
	3, 		/* y */ 
	3, 		/* z */ 
	3, 		/* { */ 
	1, 		/* | */ 
	3, 		/* } */ 
	4, 		/* ~ */ 
};
/****************************************************************************/



class HC4x4x4
{
    public: 
	    HC4x4x4(void);
        void init(void);
        void clear(void);
        void plot(int16_t x, int16_t y, int16_t z, uint8_t mode = ON);
        boolean get(int16_t x, int16_t y, int16_t z);
        void line(uint8_t x1, uint8_t y1, uint8_t z1, uint8_t x2, uint8_t y2, uint8_t z2, uint8_t mode = ON);
        void printChar(char c, int16_t col, uint8_t layer);
        void print(char* text, int16_t col, uint8_t layer);
        void printScroll(char* text, uint16_t delayms, uint8_t layer);
        void circle(float x, float y, uint8_t z, uint8_t r);
		void cube(int16_t x1, int16_t y1, int16_t z1, int16_t x2, int16_t y2, int16_t z2, boolean Solid, uint8_t mode = ON);
        void shift(uint8_t dir);
        //void printWrap(char text[], int16_t col);
        void setDrawDir(uint8_t dir);
		#ifdef BASE_LEDS
        void baseLEDs(boolean state);
		#endif
        static void _CubeTimer2();
      

    private:
        void CubeTimer2Init(byte prescaler, byte compare);
        void _bitLoc(int16_t x, int16_t y, int16_t z, uint8_t *i, uint8_t *b);
        uint8_t _Diff(uint8_t a, uint8_t b);
        float _pol(float x, float y);
};


#endif