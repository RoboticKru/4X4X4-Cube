#include "Arduino.h"
#include "HC4x4x4_Patterns.h"



pattern::pattern(void)
{

}

void pattern::countdown(uint8_t startVal, uint16_t speed)
{
    do
    {
        for(uint8_t c = 0; c < 4; c++)
        {
            printChar(startVal + '0', 0, c);
            delay(speed);
            clear();
        }
        startVal--;
    } while (startVal);
}

void pattern::cubeFlash(uint16_t speed)
{
    for(uint8_t i = 0; i < 10; i++)
    {
        cube(0, 0, 0, 3, 3, 3, true);
        baseLEDs(ON);
        delay(speed);
        clear();
        baseLEDs(OFF);
        delay(speed);
    }

    baseLEDs(ON);
}


void pattern::slide(uint16_t cycles, uint16_t speed, uint8_t dir)
{
    uint8_t x, y;

    setDrawDir(dir);

	
    cube(0, 0, 0, 3, 3, 0, true);

	while(cycles)
	{
    	/* Slide all 16 LEDs */
		for(uint8_t i = 0; i < 16; i++)
		{
			/* Pick a random LED to slide */
			do
			{
				x = rand() % 4;
				y = rand() % 4;
			}while(!get(x, y, 0));
		
			/* Slide the LED to the other side of the cube */
			for(uint8_t z = 0; z < 3; z++)
			{
				plot(x, y, z, OFF);
				plot(x, y, z+1);

				delay(speed);
			}
		}


		/* Slide all 16 LEDs */
		for(uint8_t i = 0; i < 16; i++)
		{
			/* Pick a random LED to slide */
			do
			{
				x = rand() % 4;
				y = rand() % 4;
			}while(!get(x, y, 3));
		
			/* Slide the LED to the other side of the cube */
			for(uint8_t z = 3; z > 0; z--)
			{
				plot(x, y, z, OFF);
				plot(x, y, z - 1);

				delay(speed);
			}
		}
		
		cycles--;
	}
    setDrawDir(FRONT_0);
    clear();
}



void pattern::frame(uint16_t cycles, uint16_t speed, uint8_t dir)
{
    setDrawDir(dir);

	while(cycles)
	{
    	for(uint8_t z = 0; z < 4; z++)
    	{
        	clear();
        	cube(0, 0, z, 3, 3, z, true);
        	delay(speed);    
    	}

		for(int8_t z = 3; z >= 0; z--)
    	{
        	clear();
        	cube(0, 0, z, 3, 3, z, true);
        	delay(speed);    
    	}
		cycles--;
	}

    setDrawDir(FRONT_0);
    clear();
}


void pattern::starField(uint16_t cycles, uint16_t speed, uint8_t dir)
{
    setDrawDir(dir);

    for(uint8_t x = 0; x < cycles; x++)
    {
        plot(random(4), random(4), 0);
        plot(random(4), random(4), 0);
        
        delay(speed);
        shift(BACKWARD);
    }    

    setDrawDir(FRONT_0);
    clear();
}

void pattern::randomFill(uint16_t speed)
{
    uint8_t x, y, z;

    for(uint8_t i = 0; i < 64; i++)
	{
		/* Pick a random LED to slide */
		do
		{
			x = rand() % 4;
			y = rand() % 4;
            z = rand() % 4;
		}while(get(x, y, z));

        plot(x, y, z);
        
        delay(speed);
    }
}

void pattern::randomClear(uint16_t speed)
{
    uint8_t x, y, z;

    for(uint8_t i = 0; i < 64; i++)
	{
		/* Pick a random LED to slide */
		do
		{
			x = rand() % 4;
			y = rand() % 4;
            z = rand() % 4;
		}while(!get(x, y, z));

        plot(x, y, z, OFF);
        
        delay(speed);
    }
}


void pattern::ledBounce(uint16_t speed, uint8_t objects)
{
	uint8_t i;
    uint16_t cycles = 500;
	
	/* Contains information about the location and direction of each cube */
	struct cubeType
	{
		float x1,y1,z1;
		float dx1, dy1, dz1;
	};
	
	cubeType cubeData[objects];
	
	
	/* Set the initial random location and direction of each cube */
	for (i=0; i < objects; i++)
	{
		cubeData[i].x1 = random(0, 2);
		cubeData[i].y1 = random(0, 2);
		cubeData[i].z1 = random(0, 2);
		
		cubeData[i].dx1 = (float)random(1, 10) / (float)10;
		cubeData[i].dy1 = (float)random(1, 10) / (float)10;
		cubeData[i].dz1 = (float)random(1, 10) / (float)10;
	}

	/* Bounce each cube */
	do
	{
		clear();
		for (i=0; i < objects; i++)
		{
            
		
			if(cubeData[i].x1 < 0 || cubeData[i].x1 > 3.5)
				cubeData[i].dx1 *= -1;
			if(cubeData[i].y1 < 0 || cubeData[i].y1 > 3.5)
				cubeData[i].dy1 *= -1;
			if(cubeData[i].z1 < 0 || cubeData[i].z1 > 3.5)
				cubeData[i].dz1 *= -1;

			cubeData[i].x1 += cubeData[i].dx1;
			cubeData[i].y1 += cubeData[i].dy1;
			cubeData[i].z1 += cubeData[i].dz1;

		
		//	cube((uint8_t)cubeData[i].x1,(uint8_t)cubeData[i].y1,(uint8_t)cubeData[i].z1,
		//		(uint8_t)cubeData[i].x1,(uint8_t)cubeData[i].y1,(uint8_t)cubeData[i].z1,true);
            plot((uint8_t)cubeData[i].x1,(uint8_t)cubeData[i].y1,(uint8_t)cubeData[i].z1);
        }
		
	
			delay(speed);
		
		cycles--;
	}while(cycles);	
	
}


void pattern::sineWave(uint16_t cycles, uint16_t speed)
{

	

	do
	{
        shift(LEFT);

		for(uint8_t z = 0; z < 4; z++)
		{
			
            plot(3,(sin((float)cycles) + 1) * 2 , z);
			
		}
		
	
			delay(speed);
		
		
		
		cycles--;
	}while(cycles);	
}


void pattern::lineDance(uint16_t cycles, uint16_t speed)
{
	float x1,y1,z1,x2,y2,z2;
	float dx1, dy1, dz1, dx2, dy2, dz2;
	
	/* Set an initial starting position for each end of the line */
	x1 = 1;
	y1 = 2;
	z1 = 3;
	
	x2 = 2;
	y2 = 1;
	z2 = 1;
	
	/* Set an initial direction for each end of the line */
	dx1 = 0.2;
	dy1 = 0.4;
	dz1 = 0.3;
	
	dx2 = -0.1;
	dy2 = -0.2;
	dz2 = -0.3;
	
	/* Bounce the line around the cube */
	do
	{
		if(x1 <= 0 || x1 >= 3.5)
			dx1 *= -1;
		if(y1 <= 0 || y1 >= 3.5)
			dy1 *= -1;
		if(z1 <= 0 || z1 >= 3.5)
			dz1 *= -1;
		if(x2 <= 0 || x2 >= 3.5)
			dx2 *= -1;
		if(y2 <= 0 || y2 >= 3.5)
			dy2 *= -1;
		if(z2 <= 0 || z2 >= 3.5)
			dz2 *= -1;
			
		x1 += dx1;
		y1 += dy1;
		z1 += dz1;
		x2 += dx2;
		y2 += dy2;
		z2 += dz2;
		
		clear();
		line(x1,y1,z1,x2,y2,z2);
		
	
			delay(speed);
		
		cycles--;
	}while(cycles);	
	
}


void pattern::plasmaBall(unsigned int cycles, unsigned int speed)
{
	do
	{
		clear();
		line(1,1,1,rand()%4,rand()%4,rand()%4);
		line(1,1,2,rand()%4,rand()%4,rand()%4);
		line(1,2,1,rand()%4,rand()%4,rand()%4);
		line(1,2,2,rand()%4,rand()%4,rand()%4);
		line(2,1,1,rand()%4,rand()%4,rand()%4);
		line(2,1,2,rand()%4,rand()%4,rand()%4);
		line(2,2,1,rand()%4,rand()%4,rand()%4);
		line(2,2,2,rand()%4,rand()%4,rand()%4);
		
		
			delay(speed);
		
		cycles--;
	}while(cycles);	
}


/* Draws an expanding wire frame cube from one corner to another where:
   Cycles is the number of repetitions. Valid values are from 1 to 1023 
   
   Speed is the speed at which to step though each frame of the animation in 1ms increments. Valid values are from 1 to 1023. */
void pattern::wireCube(uint16_t cycles, uint16_t speed, uint8_t dir)
{
	uint8_t i, step;

    setDrawDir(dir);

	do
	{	
	
		for(step = 0; step < 4; step++)
		{
			for(i = 0; i < 4; i++)
			{
				clear();
				switch(step)
				{
					case(0):
						cube(0, 0, 0, i, i, i, false);
						break;
					case(1):
						cube(i, i, i, 3, 3, 3, false);
						break;
					case(2):
						cube(3-i, 3-i, 3-i, 3, 3, 3, false);
						break;
					case(3):
						cube(0, 0, 0, 3-i, 3-i, 3-i, false);
						break;
					case(4):
						cube(0, 3, 0, i, 3 - i, i, false);
						break;
					case(5):
						cube(i, 3 - i, i, 3, 0, 3, false);
						break;
					case(6):
						cube(3-i, i, 3-i, 3, 0, 3, false);
						break;
					case(7):
						cube(0, 3, 0, 3-i, i, 3-i, false);
						break;			
				}
				
			
				delay(speed);
		
			}	
		}
		cycles--;
	}while(cycles);

    setDrawDir(FRONT_0);
}


/* Slides an 8x8x8 cube from the right side to the left side where:
   Cycles is the number of repetitions. Valid values are from 1 to 1023 
   
   Speed is the speed at which to step though each frame of the animation in 1ms increments. Valid values are from 1 to 1023. */
void pattern::cubeSlide(uint16_t cycles, uint16_t speed)
{
	byte startIndex, endIndex;
	do
	{	
		for(startIndex = 0; startIndex < 12; startIndex++)
		{
			clear();
			if(startIndex < 8)
			{
				endIndex = 0;
				if(startIndex > 3)
					endIndex = startIndex - 3;
				cube(startIndex, 0, 0, endIndex, 3, 3, true);
				
			}
			
		
				delay(speed);
	
		}
		cycles--;
	}while(cycles);
}



/* Moves four 4x4x4 LED cubes in a pattern where:
   Cycles is the number of repetitions. Valid values are from 1 to 1023 
   
   Speed is the speed at which to step though each frame of the animation in 1ms increments. Valid values are from 1 to 1023. */
void pattern::cubeSwap(uint16_t cycles, uint16_t speed)
{
	uint8_t startIndex, endIndex, loopIndex, dir;
	//boolean fill;
	do
	{	
		
		
		for(loopIndex = 0; loopIndex < 4; loopIndex++)
		{	
			//loopIndex < 2? fill = true: fill = false;
				
			for(dir = 0; dir < 4; dir++)
			{
				
				for(startIndex = 0; startIndex <= 2; startIndex++)
				{
					clear();

					switch(dir)
					{
						case(0):
							cube(startIndex, 0, 2, startIndex+1, 1, 3, true);
							cube(3-startIndex, 2, 2, 2 - startIndex, 3, 3, true);
							cube(3-startIndex, 0, 0, 2 - startIndex, 1, 1, true);
							cube(startIndex, 2, 0, startIndex+1, 3, 1, true);
					
							break;
						
						case(1):
							cube(2, startIndex, 2, 3, startIndex + 2, 3, true);
							cube(0, 3 - startIndex, 2, 1, 2 - startIndex, 3, true);
							cube(2, 3 - startIndex, 0, 3, 2 - startIndex, 1, true);
							cube(0, startIndex, 0, 1, startIndex + 1, 1, true);
							break;

						case(2):
							cube(2, 2, 2 - startIndex, 3, 3, 3 - startIndex, true);
							cube(0, 0, 2 - startIndex, 1, 1, 3 - startIndex, true);
							cube(2, 0, startIndex, 3, 1, startIndex + 1, true);
							cube(0, 2, startIndex, 1, 3, startIndex + 1, true);
							break;

						case(3):
							cube(2, startIndex, 2, 3, startIndex + 1, 3, true);
							cube(0, 3 - startIndex, 2, 1, 2 - startIndex, 3, true);
							cube(2, 3 - startIndex, 0, 3, 2 - startIndex, 1, true);
							cube(0, startIndex, 0, 1, startIndex + 1, 1, true);
							break;		
					}
					
		
					delay(speed);

				}
			}
		}
		cycles--;
	}while(cycles);
}


void pattern::matrix(/*uint16_t cycles,*/ uint16_t speed)
{
	uint8_t density = 1;

	//3 
	//2 *
	//1 *
	//0

shift(DOWN);

	for(uint8_t i = 0; i < density; i++)
	{
		
		plot(rand()%4, 3, rand()%4);
	}

	
	//for(uint8_t i = 0; i < 2; i++)
		for(uint8_t z = 0; z < 3; z++)
			for(uint8_t x = 0; x < 3; x++)
			{
				uint8_t y = 0;
				while(get(x,2 - y,z) && y < 3)
					y++;


				//uint8_t c = 0;
				//for(uint8_t y = 0; y < 2; y++)
				//	if(get(x,y,z) && get(x,2,z))
			//			c++;
				if(y < 3 && get(x,2,z))
					plot(x,3,z);
			}

			//	if((!get(x, 0, z) || !get(x, 1, z)) && get(x, 2, z))
		//			plot(x,3,z);

		delay(speed);

/*	struct elements
	{
		uint8_t x, y, c;
	};

	elements elementData[density];

	for(uint8_t i = 0; i < density; i++)
	{
		elementData[i].x = rand()%4;
		elementData[i].y = rand()%4;
		elementData[i].c = 0;




	}*/


}

void pattern::revolve(uint16_t cycles, uint16_t speed)
{
	while(cycles)
	{
		for(float i = 0; i < 12; i++)
   		{
      		// -1 +1
      		float x = sin(i * 2 * PI / 12);
      		float z = cos(i * 2 * PI / 12);
      

      		clear();
      		for(uint8_t y = 0; y < 4; y++)
      		{
      			float r = 1.5;
      			plot((x * r) + 1.5 + 0.5, y, (z * r) + 1.5 + 0.5);
      			
				r = 0.5;
      			plot((x * r) + 1.5 + 0.5, y, (z * r) + 1.5 + 0.5);

      			r = -0.5;
      			plot((x * r) + 1.5 + 0.5, y, (z * r) + 1.5 + 0.5);

      			r = -1.5;
      			plot((x * r) + 1.5 + 0.5, y, (z * r) + 1.5 + 0.5);
      		}
      		
			  delay(speed);
   		}
   		
		cycles--;
	};
}


void pattern::lineSpin(uint16_t cycles, uint16_t speed)
{
	while(cycles)
	{
for(float i = 0; i < 12; i++)
   		{
      		// -1 +1
      		float x = sin(i * 2 * PI / 12);
      		float z = cos(i * 2 * PI / 12);
      
      		clear();

      		//for(uint8_t y = 0; y < 4; y++)
      		{
      			float r = 1.5;

				uint8_t x1 = (x * r) + 1.5 + 0.5;
				uint8_t z1 = (z * r) + 1.5 + 0.5;
				r = -1.5;
				uint8_t x2 = (x * r) + 1.5 + 0.5;
				uint8_t z2 = (z * r) + 1.5 + 0.5;

      			line(x1,-1,z1,x2,4,z2);
      		}
      		
			  delay(speed);
   		}
   		
		cycles--;
	};
}


void pattern::snake(uint16_t speed)
{
	//int8_t len = 1, x = 0, y = 0, z = 0, dx = 1, dy = 0, dz = 0;

	uint8_t dir = 0,/*, x = 0, y = 0, z = 0,*/ len = 1;  //36 20

	unsigned long time = millis();

	snakeBody b[64];

	clear();

	for(uint8_t i = 0; i < 64; i++)
	{
		b[i].x = 0;
		b[i].y = 0;
		b[i].z = 0;
	}
	

	do
	{
		/*Serial.print(b[0].x); Serial.print('\t');
		Serial.print(b[0].y); Serial.print('\t');
		Serial.print(b[0].z); Serial.print('\t');
		Serial.println(dir); */

		
		if(!_pathClear(b, dir))
		switch(dir)
		{
			// LEFT
			case 0:
				//if(!_pathClear(b, 0))
				{
					if(_pathClear(b, 4))
						dir = 4; // UP
					else if(_pathClear(b, 1))
						dir = 1; // FORWARD
					else if(_pathClear(b, 3))
						dir = 3; // DOWN
					
					else if(_pathClear(b, 5))
						dir = 5; // BACK
					else
						dir = 6; // DEAD END
				}
				//Serial.print("DIR: ");Serial.println(dir); 
				break;

			// FORWARD
			case 1:
			//	if(!_pathClear(b, 1))
				{
					if(_pathClear(b, 0))
						dir = 0; // LEFT
					else if(_pathClear(b, 2))
						dir = 2; // RIGHT
					else if(_pathClear(b, 3))
						dir = 3; // DOWN
					else if(_pathClear(b, 4))
						dir = 4; // UP
					else
						dir = 6; // DEAD END
				}
				break;

			// RIGHT
			case 2:
			//	if(!_pathClear(b, 2))
				{
					if(_pathClear(b, 1))
						dir = 1; // FORWARD
					else if(_pathClear(b, 3))
						dir = 3; // DOWN
					else if(_pathClear(b, 4))
						dir = 4; // UP
					else if(_pathClear(b, 5))
						dir = 5; // BACK
					else
						dir = 6; // DEAD END
				}
				break;

			// DOWN
			case 3:
			//	if(!_pathClear(b, 3))
				{
				
					if(_pathClear(b, 0))
						dir = 0; // LEFT
					else if(_pathClear(b, 1))
						dir = 1; // FORWARD
					else if(_pathClear(b, 2))
						dir = 2; // RIGHT
					else if(_pathClear(b, 5))
						dir = 5; // BACK
					else
						dir = 6; // DEAD END
				}
				break;

			// UP
			case 4:
			//	if(!_pathClear(b, 4))
				{
					if(_pathClear(b, 5))
						dir = 5; // BACK
					else if(_pathClear(b, 0))
						dir = 0; // LEFT
					else if(_pathClear(b, 1))
						dir = 1; // FORWARD
					else if(_pathClear(b, 2))
						dir = 2; // RIGHT
					
					else
						dir = 6; // DEAD END
				}
				break;

			// BACK
			case 5:
			//	if(!_pathClear(b, 5))
				{
					if(_pathClear(b, 3))
						dir = 3; // DOWN
					else if(_pathClear(b, 0))
						dir = 0; // LEFT
					else if(_pathClear(b, 4))
						dir = 4; // UP
					else if(_pathClear(b, 2))
						dir = 2; // RIGHT
					
					else
						dir = 6; // DEAD END
				}
				break;

		}			

		if(dir < 6)
		{
			for(uint8_t i = len; i > 0; i--)
				b[i] = b[i - 1];

			switch(dir)
			{
				// LEFT
				case 0:
					b[0].x--;
					break;

				// FORWARD
				case 1:
					b[0].z++;
					break;

				// RIGHT
				case 2:
					b[0].x++;
					break;

				// DOWN
				case 3:
					b[0].y--;
					break;

				// UP
				case 4:
					b[0].y++;
					break;

				// BACK
				case 5:
					b[0].z--;
					break;
			}

			//Serial.println(dir);
			clear();

			for(uint8_t i = 0; i < len; i++)
				plot(b[i].x, b[i].y, b[i].z);

			delay(speed);
		}

		if( millis() - time > 2500)
		{
			time = millis();
			len++;
			//Serial.print(time);
		}
	}while(dir != 6);
	/*do
	{
	boolean ok = true;
	
	switch(dir)
	{	
		// LEFT
		case 0:
			if(x > 0)
				x--;
			else
			{
				dir = 1; // forward
				ok = false;
			}
			break;

		// FORWARD
		case 1:
			if(z < 3)
				z++;
			else
				if
	}
	while(ok)

	plot(x,y,z);

	delay(speed);*/
}


boolean pattern::_pathClear(snakeBody *b, uint8_t dir)
{
	switch(dir)
	{
		// LEFT
		case 0:
	//	Serial.print("CASE 0: ");Serial.println(b[0].x);
			if(b[0].x > 0 && !get(b[0].x - 1, b[0].y, b[0].z))
				return true;
			break;

		// FORWARD
		case 1:
	//	Serial.print("CASE 0: ");Serial.println(b[0].z);
			if(b[0].z < 3 && !get(b[0].x, b[0].y, b[0].z + 1))
				return true;
			break;


		// RIGHT
		case 2:
			if(b[0].x < 3 && !get(b[0].x + 1, b[0].y, b[0].z))
				return true;
			break;

		// DOWN
		case 3:
			if(b[0].y > 0 && !get(b[0].x, b[0].y - 1, b[0].z))
				return true;
			break;

		// UP
		case 4:
			if(b[0].y < 3 && !get(b[0].x, b[0].y + 1, b[0].z))
				return true;
			break;

		// BACK
		case 5:
			if(b[0].z > 0 && !get(b[0].x, b[0].y, b[0].z - 1))
				return true;
			break;
	}
	return false;
}