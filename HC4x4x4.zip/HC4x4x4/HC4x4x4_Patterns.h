#ifndef PATTERNS_H
#define PATTERNS_H
#include "HC4x4x4.h"



struct snakeBody
	{
		uint8_t x,y,z;
	};

class pattern: private HC4x4x4
{
    public:
        pattern(void);
        void countdown(uint8_t startVal, uint16_t speed);
        void cubeFlash(uint16_t speed);
        void slide(uint16_t cycles, uint16_t speed, uint8_t dir);
        void frame(uint16_t cycles, uint16_t speed, uint8_t dir);
        void starField(uint16_t cycles, uint16_t speed, uint8_t dir);
        void randomFill(uint16_t speed);
        void randomClear(uint16_t speed);
        void ledBounce(uint16_t speed, uint8_t objects);
        void sineWave(uint16_t cycles, uint16_t speed);
        void lineDance(uint16_t cycles, uint16_t speed);
        void plasmaBall(unsigned int cycles, unsigned int speed);
        void wireCube(uint16_t cycles, uint16_t speed, uint8_t dir);
        void cubeSlide(uint16_t cycles, uint16_t speed);
        void cubeSwap(uint16_t cycles, uint16_t speed);
        void matrix(/*uint16_t cycles,*/ uint16_t speed);
        void revolve(uint16_t cycles, uint16_t speed);
        void snake(uint16_t speed);
        void lineSpin(uint16_t cycles, uint16_t speed);

    private:
        boolean _pathClear(snakeBody *b, uint8_t dir);
};

#endif