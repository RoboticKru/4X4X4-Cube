/* FILE:    HC4x4x4_Library_Examples
   DATE:    19/11/21
   VERSION: 1.0
   AUTHOR:  Andrew Davies
   
19/11/21 version 1.0: Original version

NOTE: IF THIS SKETCH DOES NOT DISPLAY CORRECTLY you will need to open the 
version.h file in a text editor and select your version of cube.
*/

#include "HC4x4x4.h"

// Create an instance of the HC4x4x4 library
HC4x4x4 HC4x4x4;

void setup() 
{
  // Initialise the library
  HC4x4x4.init();
}

void loop() 
{

/****************************************************************************/
//                            PLOT EXAMPLES
/****************************************************************************/
  // Turn on LED at x,y,z coordinate 0,0,0
  HC4x4x4.plot(0,0,0, ON);
  delay(4000);

  // Plot across x axis
  HC4x4x4.plot(1,0,0, ON);
  HC4x4x4.plot(2,0,0, ON);
  HC4x4x4.plot(3,0,0, ON);
  delay(4000);

  // Plot across y axis
  HC4x4x4.plot(0,1,0, ON);
  HC4x4x4.plot(0,2,0, ON);
  HC4x4x4.plot(0,3,0, ON);
  delay(4000);

  // Plot across z axis
  HC4x4x4.plot(0,0,1, ON);
  HC4x4x4.plot(0,0,2, ON);
  HC4x4x4.plot(0,0,3, ON);
  delay(4000);


  // Turn off LED at x,y,z coordinate 0,0,0
  HC4x4x4.plot(0,0,0, OFF);
  delay(4000);

  // Toggle the state of the LED at 0,0,0
  for(byte i = 0; i < 10; i++)
  {
    HC4x4x4.plot(0,0,0, INVERT);
    delay(500);
  }


/****************************************************************************/
//                            LINE EXAMPLE
/****************************************************************************/
  // Draw a line
  HC4x4x4.line(0,0,0, 3,3,3, ON);
  delay(4000);


/****************************************************************************/
//                            CUBE EXAMPLES
/****************************************************************************/
  // Draw a cube with opposite corners at 1,1,1 & 2,2,2, make it solid (true)
  HC4x4x4.cube(1,1,1, 2,2,2, true);
  delay(4000);

   // Draw a bigger cube but make it hollow
  HC4x4x4.cube(0,0,0, 3,3,3, false);
  delay(4000);


/****************************************************************************/
//                            SHIFT EXAMPLE
/****************************************************************************/
  // Shift left
  for(byte i = 0; i < 4; i++)
  {
    HC4x4x4.shift(LEFT);
    delay(1000);
  }
/****************************************************************************/
  

/****************************************************************************/
//                            TEXT EXAMPLES
/****************************************************************************/
  // Print an 'A' starting a x axis column 0 and z axis layer 0
  HC4x4x4.print("X", 0, 0);
  delay(4000);

  // Print it on the left of the cube
  HC4x4x4.clear();
  HC4x4x4.setDrawDir(LEFT_0);
  HC4x4x4.print("X", 0, 0);
  delay(4000);

  // Print it on the right of the cube
  HC4x4x4.clear();
  HC4x4x4.setDrawDir(RIGHT_0);
  HC4x4x4.print("X", 0, 0);
  delay(4000);

  // Print it on the right of the cube
  HC4x4x4.clear();
  HC4x4x4.setDrawDir(TOP_0);
  HC4x4x4.print("X", 0, 0);
  delay(4000);

  // Turn off all LEDs and put the reference back to the bottom left corner
  HC4x4x4.clear();
  HC4x4x4.setDrawDir(FRONT_0);

  // Scroll some text with a 200ms delay on z axis layer 0
  HC4x4x4.printScroll("Hello World!", 200, 0);
  delay(4000);
 /****************************************************************************/
}
