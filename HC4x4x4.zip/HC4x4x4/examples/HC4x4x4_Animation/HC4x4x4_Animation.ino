/* FILE:    HC4x4x4_Animation
   DATE:    19/11/21
   VERSION: 1.0
   AUTHOR:  Andrew Davies
   
19/11/21 version 1.0: Original version

This is the default animation sketch that is shipped with the cube. It can 
be used to restore your cube back to its factory default state.

The sketch will step through all the predefined animations found in the
pattern library.

NOTE: IF THIS SKETCH DOES NOT DISPLAY CORRECTLY you will need to open the 
version.h file in a text editor and select your version of cube.

This library is provided free to support the open source community. PLEASE
SUPPORT HOBBY COMPONENTS so that we can continue to provide free content like
this by purchasing items from our store - HOBBYCOMPONENTS.COM 

You may copy, alter and reuse this code in any way you like, but please leave
reference to HobbyComponents.com in your comments if you redistribute this code.
This software may not be used directly for the purpose of selling products that
directly compete with Hobby Components Ltd's own range of products.

THIS SOFTWARE IS PROVIDED "AS IS". HOBBY COMPONENTS MAKES NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, ACCURACY OR LACK OF 
NEGLIGENCE. HOBBY COMPONENTS SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR ANY 
DAMAGES, INCLUDING, BUT NOT LIMITED TO, SPECIAL, INCIDENTAL OR CONSEQUENTIAL 
DAMAGES FOR ANY REASON WHATSOEVER.
*/

#include "HC4x4x4.h"
#include "HC4x4x4_Patterns.h"

// Create an instance of the HC4x4x4 library
HC4x4x4 HC4x4x4;
// Create an instance of the pattern library
pattern pattern;


void setup() 
{
  // Initialise the library
  HC4x4x4.init();

  // Turn on all the LEDs for 5 seconds (useful for testing the LEDS)
  HC4x4x4.cube(0,0,0,3,3,3, true);
  delay(5000);

  // Display a start message
  HC4x4x4.printScroll("4X4X4 LED CUBE DEMO  ", 150, 0);

  // Countdown to the demo
  pattern.countdown(5, 200);
  pattern.cubeFlash(200);
}


void loop() 
{
  /* Step through each predefined LED pattern */
  pattern.slide(4, 50, FRONT_0);
  pattern.slide(4, 50, LEFT_0);
  pattern.slide(4, 50, TOP_0);

  pattern.frame(10, 150, LEFT_0);
  pattern.frame(10, 150, FRONT_0);
  pattern.frame(10, 150, TOP_0);

  pattern.starField(100, 100, TOP_0);
  pattern.starField(100, 100, BOTTOM_0);

  pattern.starField(100, 100, LEFT_0);
  pattern.starField(100, 100, RIGHT_0);

  pattern.starField(100, 100, FRONT_0);
  pattern.starField(100, 100, BACK_0);
  
  for(uint8_t i = 0; i < 4; i++)
    HC4x4x4.printScroll("4X4X4LEDCUBE ", 150, 0);

  for(uint8_t i = 0; i < 5; i++)
  {
    pattern.randomFill(50);
    pattern.randomClear(50);
  }

  pattern.ledBounce(50, 4);

  pattern.sineWave(200, 150);

  pattern.lineDance(400, 50);

  pattern.plasmaBall(300, 75); 

  for(uint8_t i = 0; i < 5; i++)
  {
    pattern.wireCube(1, 150, FRONT_0);
    pattern.wireCube(1, 150, LEFT_0);
    pattern.wireCube(1, 150, BACK_0);
    pattern.wireCube(1, 150, RIGHT_0);
  }

  pattern.cubeSwap(4, 200);

  pattern.revolve(20, 100); 
  
  pattern.snake(100); 
}